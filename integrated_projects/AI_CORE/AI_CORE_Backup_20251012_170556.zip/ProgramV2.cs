using System;
using System.Threading.Tasks;

namespace MegaUltraAISystem
{
    /// <summary>
    /// 🚀 MEGA ULTRA AI SYSTEM - HAUPTPROGRAMM V2 🚀
    /// Vollständig autonom, erstellt eigene API-Schlüssel, komplett vernetzt
    /// </summary>
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.Title = "MEGA ULTRA AI SYSTEM V2 - VOLLSTÄNDIG AUTONOM";
            Console.Clear();
            
            ShowWelcomeBanner();

            using var integrator = new MegaUltraAIIntegratorV2();
            
            try
            {
                // System starten
                var result = await integrator.StartMegaUltraSystem();
                
                if (result.Success)
                {
                    Console.WriteLine($"\n🎉 {result.Message}");
                    Console.WriteLine("\n🤖 System läuft vollständig autonom!");
                    Console.WriteLine("📡 Alle API-Schlüssel wurden automatisch generiert");
                    Console.WriteLine("🌐 Interne Vernetzung ist aktiv");
                    Console.WriteLine("🛡️ Selbst-Heilung ist aktiviert");
                    
                    // Auf Benutzereingabe warten
                    await WaitForUserInput(integrator);
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"\n❌ Fehler: {result.Message}");
                    Console.ResetColor();
                    
                    Console.WriteLine("\n📋 LÖSUNGSVORSCHLÄGE:");
                    Console.WriteLine("1. Überprüfen Sie, ob Node.js installiert ist: node --version");
                    Console.WriteLine("2. Überprüfen Sie, ob Ollama läuft: ollama serve");
                    Console.WriteLine("3. Stellen Sie sicher, dass der server/ Ordner existiert");
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\n💀 KRITISCHER FEHLER: {ex.Message}");
                Console.ResetColor();
            }
            
            Console.WriteLine("\nDrücken Sie eine Taste zum Beenden...");
            Console.ReadKey();
        }

        private static void ShowWelcomeBanner()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔══════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                MEGA ULTRA AI SYSTEM V2                      ║");
            Console.WriteLine("║              🤖 VOLLSTÄNDIG AUTONOM 🤖                      ║");
            Console.WriteLine("║         📡 Erstellt eigene API-Schlüssel 📡                ║");
            Console.WriteLine("║            🌐 Komplett vernetzt 🌐                          ║");
            Console.WriteLine("║              🛡️ Selbst-heilend 🛡️                           ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();
            
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("🚀 Initialisierung der autonomen KI-Infrastruktur...");
            Console.ResetColor();
            Console.WriteLine();
        }

        private static async Task WaitForUserInput(MegaUltraAIIntegratorV2 integrator)
        {
            Console.WriteLine("\n📋 VERFÜGBARE BEFEHLE:");
            Console.WriteLine("  q - System beenden");
            Console.WriteLine("  s - Status anzeigen");
            Console.WriteLine("  r - System neu starten");
            Console.WriteLine("  k - Neue API-Schlüssel generieren");
            Console.WriteLine();

            while (true)
            {
                var key = Console.ReadKey(true);
                
                switch (key.KeyChar)
                {
                    case 'q':
                    case 'Q':
                        Console.WriteLine("🔴 System wird beendet...");
                        return;

                    case 's':
                    case 'S':
                        Console.WriteLine("📊 System-Status wird angezeigt...");
                        // Status wird automatisch in ShowSystemStatus() angezeigt
                        break;

                    case 'r':
                    case 'R':
                        Console.WriteLine("🔄 System wird neu gestartet...");
                        var result = await integrator.StartMegaUltraSystem();
                        Console.WriteLine(result.Success ? "✅ Neustart erfolgreich" : "❌ Neustart fehlgeschlagen");
                        break;

                    case 'k':
                    case 'K':
                        Console.WriteLine("🔑 Neue API-Schlüssel werden generiert...");
                        // Die Schlüssel werden automatisch bei jedem Start oder auf Anfrage rotiert
                        break;

                    default:
                        Console.WriteLine("❓ Unbekannter Befehl. Verwenden Sie q, s, r oder k");
                        break;
                }
            }
        }
    }
}